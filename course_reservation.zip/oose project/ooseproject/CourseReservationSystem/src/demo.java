import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.*;
import java.sql.*;

public class demo extends JFrame {

    private JButton displayButton;
    private JButton backButton; // New back button

    private JTable table;
    private DefaultTableModel tableModel;

    private Connection conn;

    public demo() {
        setTitle("Display Students Registered for Courses");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLayout(new BorderLayout());

        conn = DatabaseUtil.getConnection("course_reservation_system");

        // Create back button
        backButton = new JButton("Back");
        backButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                backToStaffHome();
            }
        });

        // Create button panel and add back button
        JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
        buttonPanel.add(backButton);

        // Create display button
        displayButton = new JButton("Display Details");
        displayButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                displayStudents();
            }
        });
        buttonPanel.add(displayButton); // Add display button to button panel

        add(buttonPanel, BorderLayout.NORTH);

        // Create JTable
        tableModel = new DefaultTableModel();
        table = new JTable(tableModel);
        tableModel.addColumn("ID");
        tableModel.addColumn("Name");
        tableModel.addColumn("Course Name");
        tableModel.addColumn("Registered Date");
        tableModel.addColumn("Course Beginning Date");
        JScrollPane scrollPane = new JScrollPane(table);
        add(scrollPane, BorderLayout.CENTER);

        pack();
        setLocationRelativeTo(null);
    }

    private void backToStaffHome() {
        staffHome staffHome = new staffHome();
        staffHome.setVisible(true);
        this.setVisible(false);
    }

    private void displayStudents() {
        // Clear existing table data
        tableModel.setRowCount(0);

        // Connect to MySQL database
        try {
            // Prepare SQL query to fetch all registered students and their courses
            String sql = "SELECT cr.id, cr.name, cr.course_name, cr.registration_date, c.course_date " +
                         "FROM courses_registered cr " +
                         "INNER JOIN courses c ON cr.course_name = c.name";
            try (Statement stmt = conn.createStatement()) {
                ResultSet rs = stmt.executeQuery(sql);

                // Add each student's details to the table
                while (rs.next()) {
                    int id = rs.getInt("id");
                    String name = rs.getString("name");
                    String courseName = rs.getString("course_name");
                    String rdate = rs.getString("registration_date");
                    String cdate = rs.getString("course_date");
                    tableModel.addRow(new Object[]{id, name, courseName, rdate, cdate});
                }
            }
        } catch (SQLException ex) {
            ex.printStackTrace();
        }
    }

    public static void main(String[] args) {
        java.awt.EventQueue.invokeLater(() -> {
            new demo().setVisible(true);
        });
    }
}
